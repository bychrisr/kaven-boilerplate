#!/usr/bin/env bash
set -euo pipefail

WORKSPACE_ROOT="$(pwd)"
KIT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

if [[ -d "$WORKSPACE_ROOT/.agent" ]]; then
  TS=$(date +"%Y%m%d_%H%M%S")
  echo "[project_install] Backup: .agent -> .agent.bak.$TS"
  mv "$WORKSPACE_ROOT/.agent" "$WORKSPACE_ROOT/.agent.bak.$TS"
fi

echo "[project_install] Installing .agent into workspace..."
cp -R "$KIT_ROOT/project/.agent" "$WORKSPACE_ROOT/.agent"

# Ensure executable bits (zip/cp can drop them)
chmod +x "$WORKSPACE_ROOT/.agent/scripts/"*.sh || true

echo "[project_install] Done. Next: edit .agent/config/quality.env to match this repo."
