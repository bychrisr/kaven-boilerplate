#!/usr/bin/env bash
set -euo pipefail

HOME_GEMINI="$HOME/.gemini"
AG_DIR="$HOME_GEMINI/antigravity"
KIT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

mkdir -p "$HOME_GEMINI" "$AG_DIR"

# 1) Global Workflows
mkdir -p "$AG_DIR/global_workflows"
cp -R "$KIT_ROOT/global/antigravity/global_workflows/." "$AG_DIR/global_workflows/"

# 2) Global Skills
mkdir -p "$AG_DIR/skills"
cp -R "$KIT_ROOT/global/antigravity/skills/." "$AG_DIR/skills/"

# 3) Global Rules
# WARNING: this file is shared with Gemini CLI on some systems.
# We DO NOT overwrite. We append a clearly delimited block.
TARGET="$HOME_GEMINI/GEMINI.md"
BLOCK="$KIT_ROOT/global/GEMINI.append.md"

if [[ ! -f "$TARGET" ]]; then
  echo "[global_install] Creating $TARGET"
  cp "$KIT_ROOT/global/GEMINI.base.md" "$TARGET"
fi

MARKER_START="<!-- KAVEN_AGENT_KIT_V3_START -->"
MARKER_END="<!-- KAVEN_AGENT_KIT_V3_END -->"

if grep -q "$MARKER_START" "$TARGET"; then
  echo "[global_install] Block already present in $TARGET (skipping append)"
else
  echo "[global_install] Appending global rules block to $TARGET"
  {
    echo ""
    cat "$BLOCK"
    echo ""
  } >> "$TARGET"
fi

echo "[global_install] Done. Restart Antigravity to reload global workflows/skills."
