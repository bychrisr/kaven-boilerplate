# Migração do `.agent` antigo → Kit v3

## Objetivo

Eliminar três classes de falha que custam caro:

1. **Afirmações sem evidência** ("está implementado" sem testes/diff)
2. **Mudanças destrutivas em docs** (README encolhe, perde seções)
3. **Gambiarras silenciosas** (workarounds que viram dívida eterna)

## Estratégia de migração recomendada

1. **Backup** do `.agent` existente.
2. Instalar este kit.
3. Rodar `/preflight` antes de qualquer tarefa grande.
4. Em todo PR, rodar `/ci-verify` e anexar o *evidence bundle* no texto do PR.

## O que foi removido/alterado do kit antigo

- Scripts com `eval` foram substituídos por runner com **argumentos seguros**.
- Telemetria antiga foi substituída por **Evidence Bundle v1** (mais simples, mais verificável).
- Workflows numerados (pontuais) viraram workflows "core" reutilizáveis + workflows específicos Kaven.

## Como provar que estamos protegidos contra “README encolheu”

Use `/doc-safe-update` para qualquer mudança em documentação.
Esse workflow exige:

- `wc -l` antes/depois
- `git diff --stat`
- explicação objetiva se remoções superarem adições

