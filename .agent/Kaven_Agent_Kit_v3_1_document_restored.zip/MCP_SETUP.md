# MCP Setup (Antigravity) — robusto e seguro

Este guia é **opinioso** (anti-gambiarra). A meta é ter ferramentas úteis **sem abrir a porta** para RCE / prompt injection.

## 1) Onde ficam as configs no Antigravity

Em setups reportados, o Antigravity armazena configurações em `~/.gemini/antigravity/` (por exemplo `mcp_config.json` e `global_workflows/`).

> Nota: também existe um conflito conhecido porque tanto o Antigravity quanto o Gemini CLI podem usar `~/.gemini/GEMINI.md`. Por isso o instalador global **não sobrescreve**, só adiciona um bloco delimitado. citeturn10view0

## 2) MCPs recomendados (mínimo útil)

### A) Filesystem MCP (oficial)

Use quando você quer permitir que o agente leia/escreva **apenas dentro de um caminho permitido**.
A referência oficial sugere executar via `npx` e passar o diretório permitido como argumento.

Exemplo (formato típico de clientes MCP):

```json
{
  "mcpServers": {
    "filesystem": {
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-filesystem", "/path/to/allowed/files"]
    }
  }
}
```

citeturn9view0

**Hard rule:** use um diretório permitido **o mais específico possível** (ex.: o root do repo, não o seu `$HOME`).

### B) Git MCP (oficial de referência) — com cuidado

A referência oficial lista um servidor Git baseado em Python e recomenda `uvx` para executar.

Exemplo:

```json
{
  "mcpServers": {
    "git": {
      "command": "uvx",
      "args": ["mcp-server-git", "--repository", "path/to/git/repo"]
    }
  }
}
```

citeturn9view0

⚠️ **Segurança (importante):** já houve relato público de vulnerabilidades no “Git MCP server” (cadeias com filesystem chegando a RCE / file tampering). Use versões corrigidas e mantenha update. citeturn6news26

## 3) Snyk (caso especial)

O Snyk para Antigravity é entregue como **plugin**. A própria documentação do Snyk afirma que **o Snyk MCP server não pode ser instalado manualmente** — use o plugin “Snyk Security” no Antigravity e (se fizer sentido) habilite “Secure at inception”. citeturn11view0turn11view1

## 4) Sugestão de política (pra não se arrepender depois)

- **Menos MCPs, melhores MCPs.** Cada servidor adicional aumenta superfície de ataque.
- **Princípio do menor privilégio:** paths curtos, repositórios explícitos, nada de permissões amplas.
- **Evidence Bundle obrigatório:** sempre que o agente “consertar” algo, tem que existir diff + testes.

## 5) Checklist de validação

Depois de instalar/configurar MCPs:

- Reinicie o Antigravity.
- Execute um comando simples via agente que leia um arquivo dentro do repo e confirme que:
  - fora do path permitido ele **não acessa**.
- Rode `/ci-verify` no workspace.
