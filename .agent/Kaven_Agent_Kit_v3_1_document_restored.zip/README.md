# Kaven Agent Kit v3 — README completo (Antigravity)

Este ZIP é um **kit de governança** para usar o Antigravity de forma **robusta e verificável** (sem “fingir que fez”, sem gambiarra, sem dívida invisível).  
Ele entrega:

- ✅ **Workspace `.agent/`** (para o repositório do Kaven — mas reutilizável em qualquer repo)
- ✅ **Pacote Global** (`~/.gemini/...`) com workflows e skills globais (prefixo `g-`)
- ✅ Scripts de evidência + validação
- ✅ Documentação de MCPs (inclui o caso do **Snyk**, que não é “instalável manualmente”)

> **Filosofia do kit:** “Sem evidência, não existe.”  
> Se o agent disser “feito ✅”, ele precisa provar com `diff`, comandos rodados e resultados (lint/type/test).

---

## Sumário

- [1. Como o Antigravity carrega `.agent`](#1-como-o-antigravity-carrega-agent)
- [2. Instalação (Workspace + Globais)](#2-instalação-workspace--globais)
- [3. Estrutura do kit](#3-estrutura-do-kit)
- [4. Regras do Workspace (Rules)](#4-regras-do-workspace-rules)
- [5. Workflows do Workspace](#5-workflows-do-workspace)
- [6. Workflows Globais (`g-*`)](#6-workflows-globais-g-)
- [7. Skills (Workspace + Globais)](#7-skills-workspace--globais)
- [8. Evidência: artifacts + scripts](#8-evidência-artifacts--scripts)
- [9. MCPs: o que instalar e como](#9-mcps-o-que-instalar-e-como)
- [10. Fluxo recomendado (dia a dia)](#10-fluxo-recomendado-dia-a-dia)
- [11. Troubleshooting](#11-troubleshooting)

---

## 1. Como o Antigravity carrega `.agent`

### 1.1 Workspace vs Global

- **Workspace**: regras/workflows/skills **do projeto**, dentro do repo (ideal para o time).  
  Caminho: `<repo>/.agent/...`

- **Global**: itens que você quer em todos os projetos (pessoais).  
  Caminho típico: `~/.gemini/antigravity/...`

O Antigravity lista isso na UI em **Agent → Customizations → Rules/Workflows** (com abas **Workspace** e **Global**).

### 1.2 Regras (Rules) exigem frontmatter YAML

Cada arquivo em `.agent/rules/*.md` precisa começar com:

```yaml
---
trigger: always_on | manual | model_decision | glob
description: "texto..."
glob: "padrão"  # obrigatório quando trigger = glob
---
```

Se o frontmatter estiver inválido (por exemplo `description:` vazio), a UI **não carrega** a rule.

---

## 2. Instalação (Workspace + Globais)

> Você pode instalar só o workspace, só o global, ou ambos.  
> Recomendação: **ambos** (global fica “padrão” pra qualquer repo, workspace traz o contrato do Kaven).

### 2.1 Instalar no projeto (Workspace)

1. Faça backup da `.agent` atual do repo (se existir).
2. Copie `project/.agent/` para `<repo>/.agent/`.

Ou execute:

```bash
bash install/project_install.sh /CAMINHO/DO/REPO
```

### 2.2 Instalar globais (Global)

```bash
bash install/global_install.sh
```

Isso instala:
- workflows globais em `~/.gemini/antigravity/global_workflows/`
- skills globais em `~/.gemini/antigravity/skills/`
- arquivos auxiliares em `~/.gemini/` (ver `global/`)

> Importante: se você já mantém um `~/.gemini/GEMINI.md`, use o arquivo `global/GEMINI.append.md` como “append” (não sobrescreva seu conteúdo sem revisão).

---

## 3. Estrutura do kit

### 3.1 Conteúdo do ZIP

- `project/.agent/` → pasta para colar no repo
- `global/` → itens globais (skills/workflows + append do GEMINI)
- `install/*.sh` → instaladores
- `MCP_SETUP.md` → instruções de MCP (inclui Snyk)
- `MIGRATION_GUIDE.md` → como migrar sem quebrar o fluxo

### 3.2 Estrutura do workspace `.agent`

```
.agent/
  rules/                # regras carregadas pelo Antigravity
  workflows/            # macros /... do workspace
  skills/               # skills específicas do Kaven
  scripts/              # scripts determinísticos (evidence + validação)
  config/               # variáveis e contratos do repo
  artifacts/            # evidências (geralmente não versionar)
  reports/              # relatórios (geralmente não versionar)
```

### 3.3 Arquivos de config (contratos)

- `.agent/config/quality.env`  
  Define comandos canônicos do repo (ex.: `LINT_CMD`, `TYPECHECK_CMD`, `TEST_CMD`).

- `.agent/config/docs.env`  
  Define targets para documentação (ex.: README principal, pastas docs).

- `.agent/config/kaven.env`  
  Define conceitos “canônicos” do Kaven (ex.: `X_SPACE_HEADER=x-space-id`, nomes de docs fonte de verdade).

> Isso é proposital: muda-se o **contrato** sem reescrever workflow.

---

## 4. Regras do Workspace (Rules)

> **Nota:** Rules são “sempre ligadas” (ou condicionais via glob/model_decision).  
> Elas não executam comandos sozinhas; elas **governam comportamento** e definem o “Done”.

Abaixo, o que cada rule faz.

### `00-truth-protocol.md` — Protocolo de Verdade & Evidência (**always_on**)
**Objetivo:** impedir “README atualizado ✅” sem prova.

**Exige, para declarar concluído:**
- `git diff --stat` e/ou patch relevante
- comandos rodados + resultados (lint/type/test quando aplicável)
- lista explícita de arquivos tocados
- quando for doc: baseline (`wc -l`) + preservação de headings (ou justificativa)

**Quando isso dispara mais:** alterações grandes em docs, refactors e “fiz X” sem mostrar como.

---

### `01-quality-gates.md` — Quality Gates (**always_on**)
**Objetivo:** padronizar “Done”.

**Proíbe merge/conclusão** sem:
- lint
- typecheck
- test
- validação do `.agent` (quando mexer em `.agent`)

---

### `02-no-gambiarra.md` — Sem gambiarras (**always_on**)
**Objetivo:** matar dívida técnica invisível.

Define “gambiarra” como:
- solução não testável
- workaround que quebra invariantes
- “depois a gente refatora”

**Exceção permitida** só com:
- justificativa explícita
- ADR (decisão registrada)
- plano de correção (prazo/owner)

---

### `03-doc-safe-update.md` — Atualização segura de docs (**glob: `**/*.md`**)
**Objetivo:** impedir que docs “encolham” sem querer.

Quando mexer em `.md`:
- baseline (`wc -l`)
- preservar headings e seções críticas (ou justificar remoção)
- evidência obrigatória (`diffstat` + resumo das mudanças)

---

### `10-kaven-sources-of-truth.md` — Kaven: fontes de verdade (**always_on**)
**Objetivo:** impedir contradição entre implementação e docs canônicos do Kaven.

Quando envolver:
- CLI v2 / IoC
- Security Core
- Marketplace/Auth
- Spaces/Entitlements

…o agent deve consultar e respeitar os documentos canônicos do repo (ou abrir ADR se precisar divergir).

---

### `20-space-context-contract.md` — Space Context Contract (**always_on**)
**Objetivo:** garantir multi-tenant fail-secure.

Regras típicas:
- `x-space-id` deve estar presente onde necessário
- ausência/invalidade deve falhar de forma segura
- testes devem cobrir os caminhos críticos

---

### `21-entitlements-gating-contract.md` — Entitlements & Gating (**always_on**)
**Objetivo:** impedir “gating só no front”.

Exige:
- checagem server-side para features monetizáveis
- UI consistente (mostrar lock/upgrade)
- testes + evidência

---

### `90-workflow-standards.md` — Padrões de workflows (**glob: `.agent/workflows/**`**)
**Objetivo:** manter workflows “curtos, auditáveis, determinísticos”.

Exige que todo workflow:
- tenha pré-voo (escopo/arquivos alvo)
- rode gates
- gere evidências
- finalize chamando `/document`

---

### `snyk_rules.md` — Segurança (Snyk / deps / CI) (**model_decision**)
**Objetivo:** aplicar boas práticas quando o contexto for segurança/dependências/pipeline.

Ativa quando:
- dependências mudam
- CI/CD muda
- código sensível muda

Exige:
- evidência de scan (Snyk/OSV)
- correção sem gambiarra
- gates verdes

---

## 5. Workflows do Workspace

> **Importante:** o kit separa dois fechamentos:
> - `/impl-notes` = notas internas + evidência (docs/agent)
> - `/document` = documentação **da aplicação** (Nextra/MDX em apps/docs/content)


> Workflows são “macros” acionadas por `/nome` na UI do Agent.

### `/preflight` (`preflight.md`)
**Para que serve:** preparar o terreno antes de mexer em algo.

**O que faz:**
- define escopo (o que vamos mudar e o que não vamos)
- identifica arquivos-alvo
- decide quais gates rodar
- inicia evidência (quando aplicável)

**Use quando:** antes de tarefas grandes, refactors, docs extensas ou segurança.

---

### `/ci-verify` (`ci-verify.md`)
**Para que serve:** rodar o pacote de qualidade completo + evidência.

**O que faz:**
- roda `lint`, `typecheck`, `test` usando `config/quality.env`
- roda validações do `.agent` via `scripts/validate_agent.sh`
- gera **Evidence Bundle** (diffstat, status, outputs)

**Use quando:** antes de declarar “pronto”, antes de abrir PR, após correções.

---

### `/retry-loop` (`retry-loop.md`)
**Para que serve:** forçar o agent a **tentar de novo de verdade**, sem “fingir”.

**O que faz:**
- lê o erro (lint/type/test)
- propõe hipóteses
- aplica correção mínima
- reroda o mesmo comando
- repete em loop (limitado) ou pede checkpoint humano

**Use quando:** qualquer gate falhar.

---

### `/verify-claim` (`verify-claim.md`)
**Para que serve:** quebrar “afirmações” em evidência verificável.

**O que faz:**
- pede/gera provas (diff, grep, contagem, outputs)
- valida que o que foi dito confere com o repo
- identifica lacunas (“você disse X, mas não existe no código”)

**Use quando:** o agent disser “implementado”, “restaurado”, “corrigido” sem mostrar prova.

---

### `/doc-safe-update` (`doc-safe-update.md`)
**Para que serve:** editar docs/README sem destruir conteúdo.

**O que faz:**
- baseline (`wc -l`)
- preserva headings/seções
- exige justificativa para remoções
- evidencia (diffstat + resumo)

**Use quando:** mexer em README, docs longas, specs.

---

### `/document` (`document.md`)
**Para que serve:** documentação pós-implementação (o fechamento obrigatório).

**O que faz:**
- atualiza `docs/standards`, `docs/runbooks`, `docs/architecture` quando fizer sentido
- cria/atualiza ADRs para decisões estruturais
- gera “como validar” e “como operar”

**Use quando:** ao final de qualquer fase/PR.

---

### Workflows específicos do Kaven (`.agent/workflows/kaven/`)

#### `/kaven-readme-update` (`kaven/readme-update.md`)
**Serve para:** atualizar o README do Kaven sem “encolher” ou resumir indevidamente.

**Inclui:**
- preservação de seções
- prova de que itens antigos continuam
- inserção incremental das novidades

---

#### `/kaven-cli-modules` (`kaven/cli-modules.md`)
**Serve para:** mudanças no sistema de módulos do Kaven CLI.

**Exige:**
- alinhamento com docs canônicos
- testes (unit/integration conforme o stack)
- evidência de qualidade

---

#### `/kaven-cli-auth-marketplace` (`kaven/cli-auth-marketplace.md`)
**Serve para:** mudanças em Auth híbrida e Marketplace seguro.

**Exige:**
- atenção a security core
- checagens server-side
- regressão zero em fluxos críticos

---

#### `/kaven-spaces-entitlements` (`kaven/spaces-entitlements.md`)
**Serve para:** alterações em Spaces + Entitlements + Gating.

**Exige:**
- contrato do `x-space-id`
- gating server-side + UI consistente
- testes e evidência

---

## 6. Workflows Globais (`g-*`)

Os globais existem para você ter “o básico” em qualquer repo, sem copiar nada.

### `g-preflight`
Pré-voo global (igual ao `/preflight`, mas genérico).

### `g-ci-verify`
Gates globais (você pode adaptar por projeto via config).

### `g-retry-loop`
Loop de correção global.

### `g-verify-claim`
Validador de afirmações global.

> Dica: mantenha globais para “método” e workspace para “contrato do produto”.

---

## 7. Skills (Workspace + Globais)

Skills são módulos acionados sob demanda (o agent decide quando usar, mas você também pode “ativar” chamando pelo nome).

### Skills globais

#### `evidence-bundle-enforcer`
**Objetivo:** forçar evidência sempre que houver claim de conclusão.

**Saída típica:**
- lista de arquivos tocados
- diffstat
- comandos rodados + outputs
- pendências

#### `doc-merge-specialist`
**Objetivo:** editar docs longas sem apagar conteúdo.

**Técnica:**
- editar por âncoras e headings
- mapear seções existentes
- inserir blocos sem reescrever tudo

---

### Skills do workspace (Kaven)

#### `kaven-domain-guard`
**Use quando:** tarefa envolver Kaven CLI, Spaces, Entitlements, Security Core, ou risco de divergência das specs.

**O que impõe:**
- respeitar docs canônicos
- abrir ADR se for divergir

#### `security-audit-lite`
**Use quando:** autenticação, tokens, licensing, marketplace, dados sensíveis.

**O que impõe:**
- checklist de segurança
- evidência de testes
- proibição de “fix rápido” inseguro

---

## 8. Evidência: artifacts + scripts

### 8.1 Onde ficam as evidências

- `.agent/artifacts/` → arquivos de evidência (status/diffstat/logs)
- `.agent/reports/` → relatórios (quando aplicável)

Essas pastas costumam ser **não versionadas** (ver `.agent/.gitignore`) — a ideia é manter isso como artifact local/CI.

### 8.2 Scripts principais

- `.agent/scripts/ag.sh`  
  Helper para executar comandos com logging controlado.

- `.agent/scripts/evidence_init.sh`  
  Captura baseline (status, diffstat, etc.) antes da execução.

- `.agent/scripts/evidence_finalize.sh`  
  Captura pós-execução e consolida evidência.

- `.agent/scripts/evidence_summary.sh`  
  Gera um resumo legível das evidências.

- `.agent/scripts/validate_agent.sh`  
  Valida estrutura `.agent/` (workflows/rules/skills mínimos).

---

## 9. MCPs: o que instalar e como

Veja `MCP_SETUP.md` para o passo-a-passo completo. Aqui vai o resumo:

### 9.1 Snyk
O “MCP do Snyk” (no contexto Antigravity) é entregue via **plugin oficial** (não é “npx install e pronto”).  
No setup, habilite o **Snyk Security** dentro do Antigravity e conecte com sua conta/token.

### 9.2 Filesystem + Git MCP
O kit inclui um exemplo de configuração de MCP (`mcp_config.json`) e instruções para:
- filesystem server via `npx`
- git server via `uvx`

> Regra: “write” só com checkpoint humano. Least privilege.

---

## 10. Fluxo recomendado (dia a dia)

### Para PRs de engenharia (código)
1. `/preflight` (definir escopo e gates)
2. implementar
3. `/ci-verify` (gates + evidência)
4. se falhar → `/retry-loop`
5. `/verify-claim` (quando precisar validar afirmações)
6. `/document` (fechar e registrar)

### Para docs grandes (README, specs)
1. `/doc-safe-update`
2. `/verify-claim` (garantir preservação de seções)
3. `/document`

---

## 11. Troubleshooting

### 11.1 Workflows aparecem, mas Rules não aparecem
- verifique frontmatter YAML válido (sem chaves vazias)
- confirme que abriu o workspace na **raiz do repo**
- reinicie/reabra o Antigravity para reindexar

### 11.2 O agent diz “feito”, mas não prova
- rode `/verify-claim`
- exija Evidence Bundle (Regra 00 + skill `evidence-bundle-enforcer`)

### 11.3 O repo tem vários stacks (TS + Python)
- ajuste `config/quality.env` para rodar gates por stack
- mantenha `/ci-verify` como “orquestrador” (não hardcode ferramentas no workflow)

---

## Referências internas do kit

- `MIGRATION_GUIDE.md` — migração segura da `.agent` antiga
- `MCP_SETUP.md` — instruções completas de MCP
- `global/GEMINI.append.md` — append de regras globais sem sobrescrever seu GEMINI existente
