---
name: g-verify-claim
---

# g-verify-claim — verificar afirmações (global)

Use quando alguém diz “está feito” e você quer prova.

Checklist:

- Arquivos citados existem?
- `git diff --stat` condiz com a narrativa?
- Rodou `lint/type/test`?
- Em docs: `wc -l` antes/depois + diff seções.

Se não houver evidência: a afirmação é inválida.
