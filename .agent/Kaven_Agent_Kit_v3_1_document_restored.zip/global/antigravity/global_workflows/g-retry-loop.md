---
name: g-retry-loop
---

# g-retry-loop — falhou? então conserta de verdade.

Quando algo falhar (tests, build, lint, script):

1) Copie o erro.
2) Faça hipótese de causa (não chute). Se necessário, inspecione configs/versões.
3) Aplique correção mínima que elimine a causa-raiz.
4) Rode novamente o comando que falhou.
5) Repita até passar.

**Proibido:** pular etapa, desativar regra, comentar teste.
