---
name: g-ci-verify
---

# g-ci-verify — gates de qualidade (global)

Objetivo: impedir merges frágeis.

## Passos

1) Rode `lint`.
2) Rode `typecheck`.
3) Rode `test` (se existir).
4) Mostre evidência:
   - outputs relevantes
   - `git diff --stat`
   - lista dos comandos executados.

Se qualquer etapa falhar: aplique `/g-retry-loop`.
