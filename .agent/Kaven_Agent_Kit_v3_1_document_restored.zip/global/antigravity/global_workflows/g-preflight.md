---
name: g-preflight
---

# g-preflight — pré-voo (global)

Use este workflow antes de qualquer mudança não-trivial.

## Passos

1) Entenda o objetivo e escreva um plano **faseado** (fases → subfases → critérios de aceite).
2) Liste os arquivos-alvo e os *sources of truth* (docs/specs) que precisam ser lidos.
3) Rode verificações mínimas (ou prepare o equivalente):
   - lint
   - typecheck
   - testes rápidos (quando existirem)
4) Só então comece a editar.

## Saída esperada

- Um plano por fases com:
  - escopo de cada fase
  - testes por fase
  - evidências exigidas
  - ponto de documentação: “rodar /document ao final”.
