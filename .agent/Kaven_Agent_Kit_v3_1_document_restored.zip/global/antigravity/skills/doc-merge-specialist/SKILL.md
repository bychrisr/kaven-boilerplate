---
name: doc-merge-specialist
description: Use quando o usuário pedir para atualizar README/docs sem perder conteúdo existente, ou quando for necessário inserir seções novas em documentação grande.
---

# Doc Merge Specialist

## Objetivo

Atualizar documentação grande sem “sumir com seções”.

## Método

1) Capturar baseline:
   - `wc -l` do arquivo
   - mapa de seções (headings)
2) Aplicar mudanças **por inserção** (preferir adicionar a remover).
3) Após editar:
   - `git diff --stat`
   - comparar headings (seções removidas precisam justificativa)

## Output

- Uma atualização aditiva
- Uma lista do que mudou
- Evidência.
