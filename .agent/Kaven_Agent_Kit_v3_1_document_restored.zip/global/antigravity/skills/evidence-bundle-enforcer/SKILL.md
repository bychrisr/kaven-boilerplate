---
name: evidence-bundle-enforcer
description: Use quando o usuário reclamar de “o agente disse que fez, mas não fez” ou quando a tarefa exigir prova (diff, lint, typecheck, tests) antes de concluir.
---

# Evidence Bundle Enforcer

## Objetivo

Impedir a classe de bug: *"afirmação sem evidência"*.

## Protocolo

1) Antes de declarar concluído, gere evidência:
   - `git diff --stat`
   - comandos executados
   - outputs de lint/type/test
2) Se mexer em documentação:
   - `wc -l` antes/depois
   - explicar qualquer redução grande
3) Se algo falhar: aplicar loop de correção até passar.

## Anti-padrões proibidos

- “Deve estar funcionando”
- “Implementei” sem logs
- “Não rodei testes mas parece ok”
