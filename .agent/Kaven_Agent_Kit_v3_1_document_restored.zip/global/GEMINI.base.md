# GEMINI.md (Global)

> Este arquivo é carregado como *contexto global*.
> Atenção: em alguns ambientes, Antigravity e Gemini CLI compartilham o mesmo caminho `~/.gemini/GEMINI.md`. citeturn10view0

## Regras globais (base)

- Seja preciso.
- Prefira evidência a opinião.
- Não invente estados do filesystem.
