<!-- KAVEN_AGENT_KIT_V3_START -->

## Kaven Agent Kit v3 — Protocolo Global (anti-alucinação)

### Protocolo de Evidência (obrigatório)

1. **Nunca declare “feito” sem evidência.**
2. Evidência mínima para declarar concluído:
   - `git diff --stat` (ou equivalente)
   - resultados de `lint` e `typecheck` (e `test` quando existir)
   - se mexeu em docs: `wc -l` antes/depois
3. Se um comando falhar, **não mascarar**: reporte o erro e aplique `/retry-loop`.

### Política anti-gambiarra

- Proibido: hacks temporários, mudanças não tipadas, `any` sem justificativa, `TODO` como substituto de design.
- Exigido: solução de longo prazo com invariantes claros.

### Política de documentação

- Em mudanças por fases: ao final de cada fase, rodar `/document`.
- Atualizações em README e docs devem usar `/doc-safe-update`.

<!-- KAVEN_AGENT_KIT_V3_END -->
