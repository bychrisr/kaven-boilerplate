---
name: retry-loop
---

# /retry-loop — corrigir até passar

Quando algo falhar:

1) Cole o erro.
2) Faça hipótese de causa.
3) Corrija a causa-raiz.
4) Rode de novo o comando que falhou.
5) Repita até passar.

## Evidência

Sempre anexar:

- comando que falhou
- erro
- correção aplicada
- comando re-rodado com sucesso
